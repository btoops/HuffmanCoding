Brandon Toops
bbid: btoops


Project 3

CSC 172 MW 2:00 - 3:15pm

Synopsis:
Run the main method. No special cases or anything in this code.
